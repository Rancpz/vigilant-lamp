package compzx;

import compzx.service.UserService;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import compzx.book.BookService;
import compzx.book.BookServiceImpl;

import javax.annotation.Resource;

@SpringBootTest
public class Test2 {

    @Autowired
    private BookService bookService;

    @Test
    public void testmybatis(){
        System.out.println(bookService.findAllBook());
    }
}

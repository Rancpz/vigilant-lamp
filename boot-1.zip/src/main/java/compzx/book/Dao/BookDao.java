package compzx.book.Dao;

import compzx.book.Book;

import java.util.List;

public interface BookDao {
    List<Book> findAllBook();
    Book findBook(int id, String name, String author);
    Book findBookByid(int id);
}

package compzx.dao;

import compzx.util.User;

import java.util.List;

public interface UserDao {
    void saveCustom();
    List<User> findAllUser();
}

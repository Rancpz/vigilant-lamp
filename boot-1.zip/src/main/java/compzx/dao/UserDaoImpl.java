package compzx.dao;

import compzx.util.User;

import java.util.List;

public class UserDaoImpl implements UserDao{
    @Override
    public void saveCustom() {
        System.out.println("调用saveCustom()方法");
    }

    @Override
    public List<User> findAllUser() {
        return null;
    }

    public UserDaoImpl() {
        System.out.println("dao实现类");
    }
}

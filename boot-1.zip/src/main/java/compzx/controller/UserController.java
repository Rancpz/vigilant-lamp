package compzx.controller;

import com.alibaba.fastjson.JSONObject;
import compzx.service.UserService;
import compzx.util.User;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletResponse;
import java.util.List;

@Controller
@RequestMapping("/user")
public class UserController {

    private UserService userService;
    @RequestMapping("/test1")
    public String test1(){
        return "home";
    }

    @RequestMapping("findAll")
    public String findAll(HttpServletResponse response){
        List<User> list = userService.findAllUser();
        return JSONObject.toJSONString(list);
    }
}

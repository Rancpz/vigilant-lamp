package compzx.service;

import org.springframework.stereotype.Service;
import compzx.util.User;

import java.util.List;

public interface UserService {
    void saveCustom();
    List<User> findAllUser();
}

package compzx.service;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import compzx.dao.UserDao;
import compzx.util.User;

import java.util.List;

@Service
@Transactional
public class UserServiceImpl implements UserService{

    private UserDao userDao;
    private String name;

    public UserServiceImpl() {
    }

    public void setUserDao(UserDao userDao) {
        this.userDao = userDao;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public void saveCustom() {
        userDao.saveCustom();
    }

    @Override
    public List<User> findAllUser() {
        return userDao.findAllUser();
    }
}
